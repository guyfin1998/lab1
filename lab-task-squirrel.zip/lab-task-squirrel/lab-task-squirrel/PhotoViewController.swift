//
//  PhotoViewController.swift
//  lab-task-squirrel
//
//  Created by Samantha Casteluche on 8/31/25.
//
import UIKit

class PhotoViewController: UIViewController {
    @IBOutlet weak var photoView: UIImageView!
    var task: Task!

    override func viewDidLoad() {
        super.viewDidLoad()
        photoView.image = task.image
    }
}
class TaskDetailViewController: UIViewController {
    ...
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        // Segue to Detail View Controller
     if segue.identifier == "PhotoSegue" {
         if let photoViewController = segue.destination as? PhotoViewController {
             photoViewController.task = task
          }
      }
  }
}

